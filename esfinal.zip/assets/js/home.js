// Home page functionality
document.addEventListener("DOMContentLoaded", () => {
  // DOM elements
  const recentPostsContainer = document.getElementById("recent-posts")
  const prevBtn = document.querySelector(".slider-btn.prev")
  const nextBtn = document.querySelector(".slider-btn.next")
  const dotsContainer = document.querySelector(".slider-dots")

  let currentSlide = 0
  let recentPosts = []
  let slidesPerView = 3
  let totalSlides = 0

  // Initialize
  init()

  async function init() {
    await loadRecentPosts()
    setupSlider()
    setupEventListeners()
    updateSlidesPerView()
  }

  async function loadRecentPosts() {
    try {
      // Fetch both Lost & Found and Activities data
      const [lostFoundResponse, activitiesResponse] = await Promise.all([
        fetch("api/lost-found/index.php?limit=10"),
        fetch("api/activities/index.php?limit=10"),
      ])

      const lostFoundData = await lostFoundResponse.json()
      const activitiesData = await activitiesResponse.json()

      // Combine and format data
      const combinedPosts = []

      // Add Lost & Found items
      if (Array.isArray(lostFoundData)) {
        lostFoundData.forEach((item) => {
          combinedPosts.push({
            id: `lf-${item.id}`,
            title: item.title,
            description: item.description,
            category: item.type === "hilang" ? "Barang Hilang" : "Barang Ditemukan",
            categoryClass: item.type === "hilang" ? "lost" : "found",
            date: item.date_occurred || item.created_at,
            location: item.location,
            user: item.user_name,
            type: "lost-found",
            icon: "fas fa-search",
            link: "lost-found.php",
            image: item.image || null, // Add image field
            category_name: item.category_name
          })
        })
      }

      // Add Activities
      if (Array.isArray(activitiesData)) {
        activitiesData.forEach((activity) => {
          combinedPosts.push({
            id: `act-${activity.id}`,
            title: activity.title,
            description: activity.description,
            category: activity.category_name,
            categoryClass: "activity",
            date: activity.event_date,
            location: activity.location,
            user: activity.user_name,
            type: "activity",
            icon: "fas fa-calendar-alt",
            link: "activities.php",
            image: activity.image || null, // Add image field
            category_name: activity.category_name
          })
        })
      }

      // Sort by date (newest first) and take first 12
      recentPosts = combinedPosts.sort((a, b) => new Date(b.date) - new Date(a.date)).slice(0, 12)

      displayRecentPosts()
    } catch (error) {
      console.error("Error loading recent posts:", error)
      showErrorState()
    }
  }

  function displayRecentPosts() {
    if (!recentPostsContainer || recentPosts.length === 0) {
      showEmptyState()
      return
    }

    const postsHTML = recentPosts.map((post) => createPostCard(post)).join("")

    recentPostsContainer.innerHTML = `
      <div class="slider-container">
        <div class="slider-wrapper">
          <div class="posts-slider" id="posts-slider">
            ${postsHTML}
          </div>
        </div>
        <button class="slider-btn prev" id="prev-btn">
          <i class="fas fa-chevron-left"></i>
        </button>
        <button class="slider-btn next" id="next-btn">
          <i class="fas fa-chevron-right"></i>
        </button>
      </div>
      <div class="slider-dots" id="slider-dots"></div>
    `

    setupSlider()
  }

  function createPostCard(post) {
    const formattedDate = new Date(post.date).toLocaleDateString("id-ID", {
      day: "numeric",
      month: "short",
      year: "numeric",
    })

    // Determine icon based on category for fallback
    const getItemIcon = (category, type) => {
      if (type === 'lost-found') {
        const iconMap = {
          'elektronik': 'laptop',
          'aksesoris': 'glasses',
          'pakaian': 'tshirt',
          'buku': 'book',
          'alat tulis': 'pen',
          'tas': 'briefcase',
          'sepatu': 'shoe-prints',
          'perhiasan': 'gem',
          'kendaraan': 'car',
          'lainnya': 'box'
        }
        const normalizedCategory = (category || '').toLowerCase()
        return iconMap[normalizedCategory] || 'search'
      } else {
        return 'calendar-alt'
      }
    }

    const fallbackIcon = getItemIcon(post.category_name, post.type)
    
    // Check if image exists and is not empty
    const hasImage = post.image && post.image.trim() !== ''

    return `
      <div class="post-card" data-type="${post.type}" onclick="window.location.href='${post.link}'">
        <div class="post-image ${hasImage ? 'has-image' : ''}">
          ${hasImage ? `
            <img src="${post.image}" 
                 alt="${post.title}" 
                 loading="lazy"
                 onerror="this.style.display='none'; this.nextElementSibling.style.display='flex';">
            <div class="fallback-icon" style="display: none; position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); font-size: 3rem; color: white;">
              <i class="fas fa-${fallbackIcon}"></i>
            </div>
          ` : `
            <i class="fas fa-${fallbackIcon}"></i>
          `}
          <div class="post-type-badge ${post.type}">
            ${post.type === "lost-found" ? "Lost & Found" : "Kegiatan"}
          </div>
        </div>
        <div class="post-content">
          <div class="post-category ${post.categoryClass}">
            ${post.category}
          </div>
          <h3 class="post-title">${post.title}</h3>
          <div class="post-meta">
            <div class="meta-item">
              <i class="fas fa-calendar"></i>
              <span>${formattedDate}</span>
            </div>
            <div class="meta-item">
              <i class="fas fa-map-marker-alt"></i>
              <span>${post.location}</span>
            </div>
            <div class="meta-item">
              <i class="fas fa-user"></i>
              <span>${post.user}</span>
            </div>
          </div>
          <p class="post-description">${post.description}</p>
        </div>
      </div>
    `
  }

  // Home page functionality - Pure JavaScript without frameworks
document.addEventListener("DOMContentLoaded", () => {
  // Slider functionality
  const slider = document.getElementById("posts-slider")
  const prevBtn = document.getElementById("prev-btn")
  const nextBtn = document.getElementById("next-btn")
  const dotsContainer = document.getElementById("slider-dots")

  if (!slider) return

  let currentSlide = 0
  let slidesPerView = 3
  const totalPosts = slider.children.length
  let totalSlides = Math.ceil(totalPosts / slidesPerView)
  let autoSlideInterval

  // Initialize slider
  function initSlider() {
    updateSlidesPerView()
    totalSlides = Math.ceil(totalPosts / slidesPerView)
    createDots()
    updateSlider()
    startAutoSlide()
    setupEventListeners()
  }

  // Update slides per view based on screen size
  function updateSlidesPerView() {
    const width = window.innerWidth
    if (width <= 480) {
      slidesPerView = 1
    } else if (width <= 768) {
      slidesPerView = 2
    } else {
      slidesPerView = 3
    }
  }

  // Create dots for navigation
  function createDots() {
    if (!dotsContainer || totalSlides <= 1) return

    dotsContainer.innerHTML = ""
    for (let i = 0; i < totalSlides; i++) {
      const dot = document.createElement("button")
      dot.className = "dot" + (i === 0 ? " active" : "")
      dot.setAttribute("data-slide", i)
      dot.addEventListener("click", () => {
        currentSlide = i
        updateSlider()
        resetAutoSlide()
      })
      dotsContainer.appendChild(dot)
    }
  }

  // Update slider position and appearance
  function updateSlider() {
    if (!slider) return

    const slideWidth = 100 / slidesPerView
    const translateX = -(currentSlide * slideWidth * slidesPerView)

    // Update slider transform
    slider.style.transform = `translateX(${translateX}%)`

    // Set width for each post card
    const cards = slider.children
    for (let i = 0; i < cards.length; i++) {
      cards[i].style.flex = `0 0 calc(${slideWidth}% - 1rem)`
      cards[i].style.maxWidth = `calc(${slideWidth}% - 1rem)`
    }

    // Update active dot
    const dots = dotsContainer.querySelectorAll(".dot")
    dots.forEach((dot, index) => {
      if (index === currentSlide) {
        dot.classList.add("active")
      } else {
        dot.classList.remove("active")
      }
    })

    // Update button states
    if (prevBtn) {
      prevBtn.disabled = currentSlide === 0
    }
    if (nextBtn) {
      nextBtn.disabled = currentSlide >= totalSlides - 1
    }
  }

  // Go to next slide
  function nextSlide() {
    if (currentSlide < totalSlides - 1) {
      currentSlide++
    } else {
      currentSlide = 0 // Loop back to start
    }
    updateSlider()
  }

  // Go to previous slide
  function prevSlide() {
    if (currentSlide > 0) {
      currentSlide--
    } else {
      currentSlide = totalSlides - 1 // Loop to end
    }
    updateSlider()
  }

  // Start auto slide
  function startAutoSlide() {
    if (totalSlides <= 1) return
    autoSlideInterval = setInterval(nextSlide, 5000)
  }

  // Stop auto slide
  function stopAutoSlide() {
    if (autoSlideInterval) {
      clearInterval(autoSlideInterval)
    }
  }

  // Reset auto slide
  function resetAutoSlide() {
    stopAutoSlide()
    startAutoSlide()
  }

  // Setup event listeners
  function setupEventListeners() {
    // Previous button
    if (prevBtn) {
      prevBtn.addEventListener("click", () => {
        prevSlide()
        resetAutoSlide()
      })
    }

    // Next button
    if (nextBtn) {
      nextBtn.addEventListener("click", () => {
        nextSlide()
        resetAutoSlide()
      })
    }

    // Touch events for mobile
    let touchStartX = 0
    let touchEndX = 0

    slider.addEventListener(
      "touchstart",
      (e) => {
        touchStartX = e.touches[0].clientX
        stopAutoSlide()
      },
      { passive: true },
    )

    slider.addEventListener(
      "touchend",
      (e) => {
        touchEndX = e.changedTouches[0].clientX
        handleSwipe()
        startAutoSlide()
      },
      { passive: true },
    )

    function handleSwipe() {
      const threshold = 50
      const diff = touchStartX - touchEndX

      if (Math.abs(diff) > threshold) {
        if (diff > 0) {
          nextSlide()
        } else {
          prevSlide()
        }
      }
    }

    // Keyboard navigation
    document.addEventListener("keydown", (e) => {
      if (e.key === "ArrowLeft") {
        prevSlide()
        resetAutoSlide()
      } else if (e.key === "ArrowRight") {
        nextSlide()
        resetAutoSlide()
      }
    })

    // Pause on hover
    slider.addEventListener("mouseenter", stopAutoSlide)
    slider.addEventListener("mouseleave", startAutoSlide)

    // Resize handler
    window.addEventListener("resize", () => {
      updateSlidesPerView()
      const newTotalSlides = Math.ceil(totalPosts / slidesPerView)

      if (newTotalSlides !== totalSlides) {
        totalSlides = newTotalSlides
        currentSlide = Math.min(currentSlide, totalSlides - 1)
        createDots()
      }

      updateSlider()
    })
  }

  // Initialize everything
  if (totalPosts > 0) {
    initSlider()
  }
})


  function setupEventListeners() {
    // Responsive slider
    window.addEventListener("resize", () => {
      updateSlidesPerView()
      totalSlides = Math.ceil(recentPosts.length / slidesPerView)
      currentSlide = Math.min(currentSlide, totalSlides - 1)
      createDots()
      updateSlider()
    })

    // Touch/swipe support for mobile
    let startX = 0
    let endX = 0

    const slider = document.getElementById("posts-slider")
    if (slider) {
      slider.addEventListener("touchstart", (e) => {
        startX = e.touches[0].clientX
      })

      slider.addEventListener("touchend", (e) => {
        endX = e.changedTouches[0].clientX
        handleSwipe()
      })
    }

    function handleSwipe() {
      const threshold = 50
      const diff = startX - endX

      if (Math.abs(diff) > threshold) {
        if (diff > 0) {
          // Swipe left - next slide
          currentSlide = currentSlide < totalSlides - 1 ? currentSlide + 1 : 0
        } else {
          // Swipe right - previous slide
          currentSlide = currentSlide > 0 ? currentSlide - 1 : totalSlides - 1
        }
        updateSlider()
      }
    }
  }

  function showEmptyState() {
    if (recentPostsContainer) {
      recentPostsContainer.innerHTML = `
        <div class="empty-state">
          <i class="fas fa-inbox"></i>
          <h3>Belum Ada Postingan</h3>
          <p>Belum ada postingan terbaru untuk ditampilkan</p>
        </div>
      `
    }
  }

  function showErrorState() {
    if (recentPostsContainer) {
      recentPostsContainer.innerHTML = `
        <div class="error-state">
          <i class="fas fa-exclamation-triangle"></i>
          <h3>Gagal Memuat Data</h3>
          <p>Terjadi kesalahan saat memuat postingan terbaru</p>
          <button class="btn-primary" onclick="location.reload()">Coba Lagi</button>
        </div>
      `
    }
  }
})